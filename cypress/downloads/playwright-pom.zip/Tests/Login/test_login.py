import time

from playwright.sync_api import Playwright, sync_playwright
from PageObjects.login_page_po import LoginPage


def test_check_login(playwright: Playwright):
    browser = playwright.chromium.launch(headless=False)
    page = browser.new_page()

    login_page = LoginPage(page)
    login_page.navigate()
    login_page.login("standard_user", "secret_sauce")


with sync_playwright() as playwright:
    test_check_login(playwright)




