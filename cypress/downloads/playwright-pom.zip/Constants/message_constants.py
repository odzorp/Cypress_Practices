class MessagesCnstants:
    def __int__(self):
        self.ACCOUNT_CREATED = "Account Created successfully."
        self.ACCOUNT_DELETED = "Account Deleted successfully."
        self.CONFIRM_ACCOUNT_DELETE = "Are you sure to delete account"