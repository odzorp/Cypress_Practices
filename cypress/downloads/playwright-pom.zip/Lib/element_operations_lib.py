class ElementOperationsLib:
    def click_an_element(self, element):
        print(f"clicking {element}")
        element.click()
        print(f"Element clicked {element}")